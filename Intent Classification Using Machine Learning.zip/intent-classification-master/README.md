## Intent-classification


The task is take labelled raw data as input and build an intent classification
model which can predict user intents from future messages that may come into the system.


![demo](./demo.gif)